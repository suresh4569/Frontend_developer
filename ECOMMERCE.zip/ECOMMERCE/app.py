from flask import Flask,render_template,request,flash,url_for,session,redirect
from otp import genotp 
from cmail import sendmail
import mysql.connector
import os
from itemid import itemidotp
mydb=mysql.connector.connect(host='localhost',
user='root',
password='Suresh@123',
db='ecommerce'
)
app=Flask(__name__)
app.secret_key='jnvnkdfjvndjs'
@app.route('/',methods=['GET','POST'])
def home():
    return render_template('homepage.html')
@app.route('/reg',methods=['GET','POST'])
def register():
    if request.method=="POST":
        username=request.form['username']
        mobile=request.form['mobile']
        email=request.form['email']
        address=request.form['address']
        password=request.form['password']
        cursor=mydb.cursor()
        cursor.execute('select email from signup')
        data=cursor.fetchall()
        cursor.execute('select mobile from signup')
        edata=cursor.fetchall()
        if(mobile,)in edata:
            flash('User already exist')
            return render_template('register.html')
        if(email,)in data:
            flash('Email address already exists')
            return render_template('register.html')
        cursor.close() 
        otp=genotp()
        subject='thanks for registering to the application'
        body=f'use this otp to register {otp}'
        sendmail(email,subject,body)
        return render_template('otp.html',otp=otp,username=username,mobile=mobile,email=email,address=address,password=password)
    else:
        return render_template('register.html')
@app.route('/otp/<otp>/<username>/<mobile>/<email>/<address>/<password>',methods=['GET','POST'])
def otp(otp,username,mobile,email,address,password):
    if request.method=='POST':
        uotp=request.form['otp']
        if otp==uotp:
            cursor=mydb.cursor()
            lst=[username,mobile,email,address,password]
            query='insert into signup values(%s,%s,%s,%s,%s)'
            cursor.execute(query,lst)
            mydb.commit()
            cursor.close()
            flash('Details registered')
            return redirect('login')
        else:
            flash('Wrong otp')
            return render_template('otp.html',otp=otp,username=username,mobile=mobile,email=email,address=address,password=password)

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=="POST":
        username=request.form['username']
        password=request.form['password']
        cursor=mydb.cursor()
        cursor.execute('select count(*) from signup where username=%s and \
        password=%s',[username,password])
        count=cursor.fetchone()[0]
        print(count)
        if count==0:
            flash('Invalid email or password')
            return render_template('login.html')
        else:
            session['user']=username
            if not session.get(username):
                session[username]={}
            return redirect(url_for('home'))
    return render_template('login.html')
@app.route('/logout')
def logout():
    if session.get('user'):
        session.pop('user')
        return redirect(url_for('home'))
    else:
        flash('already logged out!')
        return redirect(url_for('login'))
@app.route('/additems',methods=['GET','POST'])
def additems():
    if request.method=="POST":
        name=request.form['name']
        discription=request.form['desc']
        quantity=request.form['qty']
        category=request.form['category']
        price=request.form['price']
        image=request.files['image']
        valid_categories=['electronics','grocery','fashion','home']
        if category not in valid_categories:
            flash('Invalid category.please select a valid option.')
            return render_template('items.html')
        cursor=mydb.cursor()
        idotp=itemidotp()
        filename=idotp+'.jpg'
        cursor.execute("insert into additems(itemid,name,discription,qty,category,price) values(%s,%s,%s,%s,%s,%s)",[idotp,name,discription,quantity,category,price])
        mydb.commit()
        path=os.path.dirname(os.path.abspath(__file__))
        static_path=os.path.join(path,'static')
        image.save(os.path.join(static_path,filename))
        flash('Item added sucessfully!')
    return render_template('items.html')        
app.run(debug=True)